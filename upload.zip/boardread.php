﻿<!DOCTYPE html>
<html>
<body>
<?php header("Content-Type: text/html; charset=UTF-8"); 
session_start(); ?>
<?php if( (!isset($_SESSION['id'])) &&  (!isset($_SESSION['nickname'])) ){ ?>
<a href="join.html">회원가입</a><br>
<a href="login.html">로그인</a><br>
<?php } else {?>
<a href="logout.php">로그아웃</a><br>
<?php } ?>
<a href="board.php">게시판</a><br>

<?php 
header("Content-Type: text/html; charset=UTF-8");
$conn = new mysqli("localhost", "root", "a123456&", "web");
mysqli_query ($conn, 'SET NAMES utf8');
$boardnum=$_GET['x'];
$cookie_name = $boardnum; //쿠키 이름은 게시판 번호로 넣어준다.
$cookie_value = "1"; //쿠기 값으로 넣어준다.
setcookie($cookie_name, $cookie_value, time() + (86400), "/"); // 1일 동안 쿠키를 유지하도록 해준다.
if(!isset($_COOKIE[$cookie_name])) { //쿠키가 삭제되지 않는 이상 조회수는 첫 조회시만 1 증가시켜준다.
    $sql2 = "UPDATE board set hit=hit+1 WHERE boardnum=$boardnum";
    $res2 = $conn->query($sql2);
}
$sql = "select *from board where boardnum='$boardnum'";
$res = $conn->query($sql);
$row=mysqli_fetch_array($res);
if($res->num_rows!=1) {
echo "<script>alert('존재하지 않는 게시물 경로입니다.'); location.href='board.php';</script>";
exit();
}
?>
<table>
<!--  <?php $title=str_replace(">","&gt",str_replace("<","&lt",$row['boardtitle'])); echo $title; ?> -->
<tr><th colspan="3">제목 : <?php $title=str_replace(">","&gt",str_replace("<","&lt",$row['boardtitle'])); echo $title; ?></th></tr>
<tr><th>작성자 : <?php echo $row['nickname']; ?></th><th>작성일 : <?php echo $row['date']; ?></th><th>조회수 : <?php echo $row['hit']; ?></th></tr>
<tr></tr>
</table>
<div>내용 : <?php  echo str_replace("＆","&",$row['boardcontents']); ?></div>
<div><?php $sql2 = "select *from upload where starttime='".$row['starttime']."' and nickname='".$row['nickname']."'";
$res2 = $conn->query($sql2);
while($row2=mysqli_fetch_array($res2)) {
echo "<div><a href='download.php?filepath=".$row2['changename']."&filename=".$row2['realname']."'>".$row2['realname']."</a></div>";
}
?></div>

<?php if(isset($_SESSION['nickname'])) { 
if($_SESSION['nickname'] == $row['nickname']) {
echo "<a href='boardupdate.php?boardnum=".$row['boardnum']."'>게시물 수정</a>";
echo "<a href='boarddelete.php?boardnum=".$row['boardnum']."'>게시물 삭제</a>";
} 
} ?>

</body>
</html>